package com.schooldevops.apifirst.apifirstsamples;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class SkeletonApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
